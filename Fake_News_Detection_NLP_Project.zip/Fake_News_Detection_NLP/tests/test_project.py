import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from preprocessing import clean_text, load_and_validate_dataset

class TestFakeNewsProject(unittest.TestCase):
    def test_lowercase_conversion(self):
        self.assertEqual(clean_text("BREAKING NEWS"), "breaking news")

    def test_url_removal(self):
        self.assertNotIn("https", clean_text("Read https://example.com now"))

    def test_punctuation_removal(self):
        self.assertEqual(clean_text("Hello!!! World?"), "hello world")

    def test_empty_input(self):
        self.assertEqual(clean_text("   "), "")

    def test_missing_columns_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad.csv"
            pd.DataFrame({"headline": ["sample"], "label": ["real"]}).to_csv(path, index=False)
            with self.assertRaises(ValueError):
                load_and_validate_dataset(path)

    def test_both_labels_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "one_class.csv"
            pd.DataFrame({"text": ["one", "two", "three", "four", "five"],
                          "label": ["real"] * 5}).to_csv(path, index=False)
            with self.assertRaises(ValueError):
                load_and_validate_dataset(path)

    def test_duplicate_rows_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "duplicates.csv"
            rows = [{"text": f"real article number {i}", "label": "real"} for i in range(5)]
            rows += [{"text": f"fake article number {i}", "label": "fake"} for i in range(5)]
            rows.append(rows[0])
            pd.DataFrame(rows).to_csv(path, index=False)
            df = load_and_validate_dataset(path)
            self.assertEqual(len(df), 10)

    def test_pipeline_can_train_and_predict(self):
        texts = ["team wins the match sports report", "election results announced official report",
                 "secret miracle cure cures every disease", "shocking hidden plot proves everything"]
        labels = ["real", "real", "fake", "fake"]
        pipe = Pipeline([("tfidf", TfidfVectorizer()), ("model", MultinomialNB())])
        pipe.fit(texts, labels)
        self.assertIn(pipe.predict(["official election report"])[0], {"real", "fake"})

    def test_label_normalisation(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "labels.csv"
            rows = [{"text": f"real story {i}", "label": "REAL"} for i in range(5)]
            rows += [{"text": f"fake story {i}", "label": "FAKE"} for i in range(5)]
            pd.DataFrame(rows).to_csv(path, index=False)
            df = load_and_validate_dataset(path)
            self.assertEqual(set(df["label"]), {"real", "fake"})

if __name__ == "__main__":
    unittest.main()
