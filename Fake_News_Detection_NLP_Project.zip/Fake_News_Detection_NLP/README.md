# Fake News Detection Using NLP

A beginner-friendly text-classification prototype using TF-IDF and scikit-learn. It predicts whether submitted text resembles examples labelled `fake` or `real` in the training dataset.

**Important:** This project does not independently verify facts. A prediction is not proof that a news item is true or false.

## 1. Project structure

```text
Fake_News_Detection_NLP/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── news_dataset.csv
├── src/
│   ├── __init__.py
│   ├── preprocessing.py
│   └── train.py
├── models/                 # trained model is saved here
├── reports/                # metrics and confusion matrix are saved here
└── tests/
    └── test_project.py
```

## 2. Dataset format

The CSV must contain these two columns:

- `text`: news headline or article text
- `label`: `fake` or `real`

A small illustrative sample dataset is included so you can test the workflow immediately. It is synthetic demonstration data, not a trusted real-world news corpus. Do not report its scores as evidence of real-world performance. For a serious evaluation, replace it with a documented public dataset and record its source, license, collection date, and any filtering.

## 3. Setup on Windows

Open PowerShell in this project folder.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 4. Train the model

```powershell
python src\train.py
```

Or supply your own CSV:

```powershell
python src\train.py --data "data\your_news_dataset.csv"
```

The script:
1. Validates and cleans the CSV.
2. Splits data into train, validation, and test sets.
3. Compares Logistic Regression, Multinomial Naive Bayes, and Linear SVM using validation macro-F1.
4. Selects the best validation model.
5. Evaluates the selected model once on the held-out test set.
6. Saves the pipeline and evaluation files.

Outputs:
- `models/fake_news_pipeline.joblib`
- `reports/evaluation.json`
- `reports/confusion_matrix.csv`
- `reports/confusion_matrix.png`

## 5. Run the web application

Train the model first, then run:

```powershell
streamlit run app.py
```

Streamlit will show a local URL, usually `http://localhost:8501`. Open it in your browser.

## 6. Run tests

```powershell
python -m unittest discover -s tests -v
```

The test suite checks text cleaning, URL and punctuation handling, empty input, required columns, class requirements, duplicate removal, label normalisation, and basic model training/prediction.

## 7. Methodology

### Text cleaning
Convert text to lowercase, remove URLs, HTML tags, punctuation and repeated whitespace. The vectorizer tokenizes and creates features.

### TF-IDF
`TfidfVectorizer` converts text into weighted numeric word and phrase features (unigrams and bigrams). The vectorizer is part of the scikit-learn pipeline, so it is fitted on training text only.

### Classifiers
- Logistic Regression
- Multinomial Naive Bayes
- Linear Support Vector Machine

### Evaluation
Precision, recall and F1 are reported for the `fake` class, along with accuracy and macro-F1. The confusion matrix uses `fake` then `real` as its label order.

## 8. Important limitations and responsible use

- Dataset quality, label quality, source bias and duplicate articles can distort results.
- A model can learn writing style or publisher patterns instead of factual accuracy.
- Breaking news and unfamiliar topics may be misclassified.
- A high score on one dataset does not guarantee performance on new articles.
- Do not use this tool to accuse people or publishers of spreading misinformation.
- Include a human fact-checking step and consult reliable independent sources.

## 9. Before final submission

- Replace the illustrative sample CSV with a documented dataset.
- Record the dataset source and license.
- Inspect class balance and duplicates; consider duplicate leakage across splits.
- Run the tests and save their actual output.
- Train the model and include the actual generated metrics and screenshots in your report.
- Never invent accuracy or claim 100% detection.

## 10. Suggested project report sections

1. Abstract
2. Introduction and problem statement
3. Objectives and scope
4. Dataset description and license
5. System architecture
6. Text preprocessing and TF-IDF
7. Model training and selection
8. Evaluation results
9. Streamlit interface screenshots
10. Testing
11. Limitations
12. Conclusion and future enhancement
