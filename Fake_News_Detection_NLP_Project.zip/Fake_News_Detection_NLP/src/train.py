import argparse
import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, ConfusionMatrixDisplay
)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from preprocessing import load_and_validate_dataset

ROOT = Path(__file__).resolve().parents[1]

def build_candidates():
    # Vectorizer is fitted only on the training portion inside each pipeline.
    return {
        "Logistic Regression": Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=30000, min_df=1, sublinear_tf=True)),
            ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42))
        ]),
        "Multinomial Naive Bayes": Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=30000, min_df=1)),
            ("classifier", MultinomialNB())
        ]),
        "Linear SVM": Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=30000, min_df=1)),
            ("classifier", LinearSVC(class_weight="balanced", random_state=42))
        ])
    }

def calculate_metrics(y_true, y_pred):
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_fake": float(precision_score(y_true, y_pred, pos_label="fake", zero_division=0)),
        "recall_fake": float(recall_score(y_true, y_pred, pos_label="fake", zero_division=0)),
        "f1_fake": float(f1_score(y_true, y_pred, pos_label="fake", zero_division=0)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0))
    }

def main(data_path=None):
    data_path = Path(data_path) if data_path else ROOT / "data" / "news_dataset.csv"
    model_dir = ROOT / "models"
    report_dir = ROOT / "reports"
    model_dir.mkdir(exist_ok=True)
    report_dir.mkdir(exist_ok=True)

    df = load_and_validate_dataset(data_path)
    X, y = df["text"], df["label"]

    # 60% train, 20% validation, 20% final test.
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.40, random_state=42, stratify=y
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=42, stratify=y_temp
    )

    candidates = build_candidates()
    validation_results = {}
    best_name, best_score, best_model = None, -1, None

    for name, model in candidates.items():
        model.fit(X_train, y_train)
        predictions = model.predict(X_val)
        metrics = calculate_metrics(y_val, predictions)
        validation_results[name] = metrics
        if metrics["macro_f1"] > best_score:
            best_name, best_score, best_model = name, metrics["macro_f1"], model

    # The test set is evaluated only after validation-based model selection.
    test_predictions = best_model.predict(X_test)
    test_metrics = calculate_metrics(y_test, test_predictions)

    joblib.dump(best_model, model_dir / "fake_news_pipeline.joblib")
    (report_dir / "evaluation.json").write_text(json.dumps({
        "selected_model": best_name,
        "selection_metric": "validation macro F1",
        "validation_results": validation_results,
        "final_test_metrics": test_metrics,
        "dataset_rows_after_cleaning": len(df),
        "split_sizes": {"train": len(X_train), "validation": len(X_val), "test": len(X_test)},
        "warning": "Metrics describe this dataset and split only; they do not prove real-world truth detection."
    }, indent=2), encoding="utf-8")

    cm = confusion_matrix(y_test, test_predictions, labels=["fake", "real"])
    pd.DataFrame(cm, index=["actual_fake", "actual_real"],
                 columns=["predicted_fake", "predicted_real"]).to_csv(report_dir / "confusion_matrix.csv")

    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Fake-like", "Real-like"])
    disp.plot(cmap="Blues", values_format="d")
    plt.title("Final Test Confusion Matrix")
    plt.tight_layout()
    plt.savefig(report_dir / "confusion_matrix.png", dpi=150)
    plt.close()

    print(f"Selected model: {best_name}")
    print("Final test metrics:")
    for key, value in test_metrics.items():
        print(f"  {key}: {value:.4f}")
    print(f"Saved model: {model_dir / 'fake_news_pipeline.joblib'}")
    print(f"Saved report: {report_dir / 'evaluation.json'}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train and evaluate the fake-news text classifier.")
    parser.add_argument("--data", help="Path to CSV containing text and label columns.")
    args = parser.parse_args()
    main(args.data)
