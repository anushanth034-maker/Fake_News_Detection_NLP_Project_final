import re
import pandas as pd

REQUIRED_COLUMNS = {"text", "label"}

def clean_text(text: str) -> str:
    """Basic, repeatable text cleaning. Keep words; remove URLs and punctuation."""
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_and_validate_dataset(path):
    df = pd.read_csv(path)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(sorted(missing))}")

    df = df[["text", "label"]].copy()
    df["text"] = df["text"].fillna("").astype(str).map(clean_text)
    df["label"] = df["label"].astype(str).str.strip().str.lower()

    label_map = {
        "fake": "fake", "false": "fake", "0": "fake",
        "real": "real", "true": "real", "1": "real"
    }
    df["label"] = df["label"].map(label_map)
    df = df.dropna(subset=["label"])
    df = df[df["text"].str.len() > 0]
    df = df.drop_duplicates(subset=["text", "label"]).reset_index(drop=True)

    if df["label"].nunique() != 2:
        raise ValueError("After cleaning, dataset must contain both 'fake' and 'real' labels.")
    if df["label"].value_counts().min() < 5:
        raise ValueError("At least 5 examples per class are required for a stratified split.")
    return df
