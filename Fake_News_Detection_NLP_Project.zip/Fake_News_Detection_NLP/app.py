from pathlib import Path
import joblib
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "fake_news_pipeline.joblib"

st.set_page_config(page_title="Fake News Detection using NLP", page_icon="📰", layout="centered")
st.title("📰 Fake News Detection using NLP")
st.write("Enter a news headline or article. The trained classifier compares its text patterns with labelled training examples.")

if not MODEL_PATH.exists():
    st.warning("The model has not been trained yet. Follow the setup instructions in README.md and run the training script.")
    st.stop()

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

model = load_model()
news_text = st.text_area("Paste news text here", height=180, placeholder="Enter a headline or a paragraph...")
if st.button("Analyse news", type="primary", disabled=not news_text.strip()):
    prediction = model.predict([news_text])[0]
    if prediction == "fake":
        st.error("Prediction: Fake-like")
    else:
        st.success("Prediction: Real-like")
    st.caption("This is a text-pattern classification result, NOT independent fact-checking or proof that the news is true or false.")

with st.expander("How does this system work?"):
    st.write("The saved scikit-learn pipeline converts text into TF-IDF features and applies the selected classifier.")
    st.write("The model was selected using validation data. The final test metrics are saved in reports/evaluation.json.")
